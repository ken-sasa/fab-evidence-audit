# Query semantics

A valid task asks whether one listed configuration satisfies its monotone
expression in the stated target context. Only referenced requirements are active.
It does not ask whether separate configurations collectively cover the leaves.

1. Validate all fields before interpreting results.
2. Select target-context records for active configuration-requirement cells.
3. Any explicit ERROR or opposed PASS/FAIL blocks the whole task as ERROR.
4. For error-free cells, evaluate lower and upper completions of missing leaves.
   True lower bound means PASS; false upper bound means FAIL; otherwise UNKNOWN.
5. Configurations are alternatives: any PASS wins after the global integrity
   gate; all FAIL gives FAIL; otherwise UNKNOWN.
6. A PASS witness cites actual, consistent positive records in one configuration
   and the target context that suffice for the expression.

An OR route may establish PASS despite unrelated missing leaves. An input error
in another active route still blocks it under the chosen audit policy. Failure
and missing evidence therefore cannot be closed interchangeably. Repeated leaf
references use one requirement's evidence, not independent copies.

The implementation reuses the preserved v0.2 evaluation core unchanged. The
public validation and JSON adapter are new; historical studies remain archived
under their original sources and do not silently become package-version tests.
